import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;
import java.util.StringTokenizer;


public class Disassembler {

	/**
	 * @param args
	 * @throws IOException 
	 */
	
	
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		BufferedReader inputStream = null;
		PrintWriter outputStream = null;
		String asmFileName = null;
		int errClass = 1;
		int errMain = 1;
		
		Scanner scanner = new Scanner(System.in);
		System.out.println("File to open: ");
		String file_name = scanner.next();
		
		try{
			inputStream = new BufferedReader(new FileReader(file_name));
			String line = "";
			while((line=inputStream.readLine()) != null){
				if(line.contains("class")){
					errClass = 0;
					StringTokenizer tokenizer = new StringTokenizer(line);
					while(tokenizer.hasMoreTokens()){
						if(tokenizer.nextToken().equals("class")){
							asmFileName = tokenizer.nextToken();
							asmFileName += ".asm";
							//System.out.println(asmFileName);
						}
					}
				}
				if(line.contains("void main")){
					errMain = 0;
				}
			}inputStream.close();
			
			if(errClass == 0 && errMain == 0){
				line="";
				inputStream = new BufferedReader(new FileReader(file_name));
				outputStream = new PrintWriter(new FileOutputStream(asmFileName));
				
				outputStream.println(".model small");
				outputStream.println(".data");
				outputStream.println(".stack 100h");
				outputStream.println(".code");
				outputStream.println("");
				
				outputStream.println("main proc");
				outputStream.println("");
				outputStream.println("mov ax, @data");
				outputStream.println("mov ds, ax");
				outputStream.println("");
				
				while((line=inputStream.readLine()) != null){
					if(line.contains("System.out")){
						int startOfPrint = line.indexOf('(');
						int endOfPrint = line.indexOf(')');
						String print = line.substring(startOfPrint+1, endOfPrint);
						//System.out.println(print);
						
						if(print.length()<=3){
							outputStream.println("mov dl, " + print);
							outputStream.println("mov ah, 02h");
							outputStream.println("int 21h");
							outputStream.println("");
							
						}else{
							outputStream.println("lea dx, " + print);
							outputStream.println("mov ah, 09h");
							outputStream.println("int 21h");
							outputStream.println("");
						}
					}
				}
				
				outputStream.println("mov ax, 4c00h");
				outputStream.println("int 21h");
				outputStream.println("");
				outputStream.println("main endp");
				outputStream.println("end main");
				
				inputStream.close();
				outputStream.close();
			}
			
		}catch(FileNotFoundException e){
			System.out.println("Error occured.");
		}catch(IOException e){
			System.out.println("Error occured.");
		}
	}

}
